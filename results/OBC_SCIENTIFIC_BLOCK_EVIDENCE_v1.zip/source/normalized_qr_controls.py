"""Explicit scientific controls; never silently substituted into the old chain.

Both initialization choices and both scoring conventions remain named. The new
NormalizedQRTarget fixes a full-dimensional Gaussian forecast score and the
unconstrained-transition stationary covariance. This is still an EnKF
approximate target, not an exact nonlinear-model likelihood.
"""
import bootstrap
import copy
import numpy as np
from scipy.linalg import solve_discrete_lyapunov,qr,solve_triangular
from stable_filter_candidate import StableAuthorLikelihood
from locked_author_likelihood import _transition_fast,_historical_logpdf,_mvn_lhs

def model_parts(L,theta,initialization='transition_F'):
    p=L.full_from_estimated(theta);s=L._system(p);n=s.neps
    pm,qm,pt,qt,bm,bt=s.precalc
    F=qm[1,0][:-n,:-n];E=qm[1,0][:-n,-n:]
    sig=np.array([p[L.pnames.index(str(L.yy['calibration']['covariances'][k]))]for k in L.shocks])
    V=E@np.diag(sig**2)@E.T
    if initialization not in ['transition_F','historical_FT']:raise ValueError(initialization)
    P=solve_discrete_lyapunov(F if initialization=='transition_F' else F.T,V)
    Hp,Hq,hc=s.hx
    H=Hp@pm[1,0][:,:-n]+Hq@F
    J=Hp@pm[1,0][:,-n:]+Hq@E
    bq=qt[1,0][:-n]
    by=Hp@pt[1,0]+Hq@bq+hc
    return s,F,E,sig,P,H,J,bq,by

def normal_logscore(A,delta):
    v=solve_triangular(A.T,delta,lower=True,check_finite=True)
    return float(-.5*(len(delta)*np.log(2*np.pi)+2*np.log(abs(np.diag(A))).sum()+v@v))

def ensemble_path(L,theta,initialization='transition_F',nonlinear=True,upto=None):
    s,F,E,sig,P,H,J,bq,by=model_parts(L,theta,initialization)
    n=s.neps;pm,qm,pt,qt,bm,bt=s.precalc
    X=L.x_z@L._root_for_mvn(P).T;eps=L.eps_z*sig[None,None,:]
    T=len(L.Y) if upto is None else (L.ends[upto] if isinstance(upto,str) else int(upto))
    cr=np.linalg.cholesky(L.R);denom=np.sqrt(L.N-1)
    lh=np.empty(T);lf=np.empty(T);flags=np.zeros(T,int);ranks=np.empty(T,int)
    for t,z in enumerate(L.Y[:T]):
        if nonlinear:
            X,Z,fl=_transition_fast(X,eps[t],pm,qm,pt,qt,bm,bt,s.hx[0],s.hx[1],s.hx[2],s.x_bar,n)
            flags[t]=int(np.count_nonzero(fl))
        else:
            Z=X@H.T+eps[t]@J.T+by
            X=X@F.T+eps[t]@E.T+bq
        mean=Z.mean(0);Yc=(Z-mean)/denom;Xc=(X-X.mean(0))/denom
        Q,A=qr(np.vstack((Yc,cr.T)),mode='economic',check_finite=True)
        B=Xc.T@Q[:L.N];K=solve_triangular(A,B.T,lower=False,check_finite=True).T
        delta=z-mean;S=np.cov(Z.T)+L.R
        lh[t]=_historical_logpdf(delta,np.zeros(len(L.obs)),S)
        lf[t]=normal_logscore(A,delta)
        ev=np.linalg.eigvalsh(S);ranks[t]=int(np.count_nonzero(ev>1e-9*max(abs(ev))))
        X+=(z[None,:]-Z-L.mus[t])@K.T
    return {'historical':lh,'full':lf,'flags':flags,'ranks':ranks}

def rebuilt(L,N,seed):
    out=copy.copy(L);out.N=int(N);out.seed=int(seed)
    rng=np.random.RandomState(seed);T=len(L.Y)
    out.mus=_mvn_lhs(rng,np.zeros(len(L.obs)),L.R,(T,N))
    out.eps_z=_mvn_lhs(rng,np.zeros(len(L.shocks)),np.eye(len(L.shocks)),(T,N))
    out.x_z=_mvn_lhs(rng,np.zeros(L.nx),np.eye(L.nx),N)
    return out

class NormalizedQRTarget(StableAuthorLikelihood):
    """Named alternative: stationary F initialization + normalized Gaussian QR score."""
    version='normalized_qr_stationary_F_v1'
    score_mode='full_rank_gaussian'
    initialization='transition_F'
    def evaluate_full(self,p,upto=None,return_path=False):
        if return_path:
            raise ValueError('Use ensemble_path for explicit audit arrays; no overloaded forecast return contract.')
        theta=self.estimated_from_full(p)
        # The sampler only varies estimated parameters. Reject silent changes to
        # any fixed primitive when this convenience interface is used.
        if not np.array_equal(self.full_from_estimated(theta),np.asarray(p,float)):
            raise ValueError('Non-estimated parameters differ from locked model primitives.')
        return float(ensemble_path(self,theta,self.initialization,True,upto)['full'].sum())

def exact_linear_path(L,theta,initialization='transition_F',upto=None):
    """Square-root exact KF for correlated state/observation structural innovations.

    q_t=F q_(t-1)+E eps_t+bq; y_t=H q_(t-1)+J eps_t+by+v_t.
    A common eps_t enters q_t and y_t; ignoring this correlation is incorrect.
    """
    s,F,E,sig,P,H,J,bq,by=model_parts(L,theta,initialization)
    C=L._root_for_mvn(P);m=np.zeros(len(F));d=len(L.obs);cr=np.linalg.cholesky(L.R)
    Bx=E*sig[None,:];By=J*sig[None,:]
    T=len(L.Y) if upto is None else (L.ends[upto] if isinstance(upto,str) else int(upto))
    ll=[]
    for y in L.Y[:T]:
        Gx=np.column_stack((F@C,Bx,np.zeros((len(F),d))))
        Gy=np.column_stack((H@C,By,cr))
        Q,A=qr(Gy.T,mode='economic',check_finite=True)
        K=solve_triangular(A,(Gx@Q).T,lower=False,check_finite=True).T
        delta=y-(H@m+by)
        ll.append(normal_logscore(A,delta))
        m=F@m+bq+K@delta
        # Joseph-equivalent factor update avoids subtracting two covariances.
        residual_factor=Gx-K@Gy
        _,Ac=qr(residual_factor.T,mode='economic',check_finite=True)
        C=Ac.T
    return np.array(ll)

def joint_linear_prefix_logpdf(L,theta,T=4,initialization='transition_F'):
    """Independent dense joint Gaussian likelihood, not a Kalman recursion."""
    _,F,E,sig,P,H,J,bq,by=model_parts(L,theta,initialization)
    C=L._root_for_mvn(P);nx=len(F);ne=len(sig);d=len(L.obs)
    width=nx+T*(ne+d);qx=np.zeros((nx,width));qx[:,:nx]=C;m=np.zeros(nx)
    mats=[];means=[];cr=np.linalg.cholesky(L.R)
    for t in range(T):
        iy=H@qx;start=nx+t*(ne+d)
        iy[:,start:start+ne]+=J*sig[None,:]
        iy[:,start+ne:start+ne+d]+=cr
        mats.append(iy);means.append(H@m+by)
        qx=F@qx;qx[:,start:start+ne]+=E*sig[None,:]
        m=F@m+bq
    B=np.vstack(mats);cov=B@B.T
    chol=np.linalg.cholesky(cov)
    dev=L.Y[:T].reshape(-1)-np.concatenate(means)
    z=solve_triangular(chol,dev,lower=True,check_finite=True)
    return float(-.5*(len(dev)*np.log(2*np.pi)+2*np.log(np.diag(chol)).sum()+z@z))

def linear_control_path(L,theta,upto=None):
    """Experimental log target; neither unbiased nor normalized-in-data guaranteed.

    Exact cancellation holds only in the paired linear limit. No chain in this
    package uses this alternative; variance reduction does not certify bias.
    """
    exact=exact_linear_path(L,theta,'transition_F',upto)
    nonlinear=ensemble_path(L,theta,'transition_F',True,upto)['full']
    linear=ensemble_path(L,theta,'transition_F',False,upto)['full']
    return exact+(nonlinear-linear)

class LinearCVQRTarget(NormalizedQRTarget):
    """Evaluated control-variate candidate. No chain in this package uses it."""
    version='normalized_qr_stationary_F_linear_control_v1_EXPERIMENTAL'
    def evaluate_full(self,p,upto=None,return_path=False):
        if return_path:raise ValueError('Use linear_control_path for audit increments.')
        theta=self.estimated_from_full(p)
        if not np.array_equal(self.full_from_estimated(theta),np.asarray(p,float)):
            raise ValueError('Fixed model primitives were changed.')
        return float(linear_control_path(self,theta,upto).sum())
