"""Validation-only sequential fixed-K Gaussian with auxiliary shock quadrature.

One 17,945D row-major Philox random bank holds all 25 initial, 224*8 primary shock,
224*8 observation perturbation, and 224*8*8 auxiliary-shock coordinates.
Primary shocks/obs perturbations alone propagate paired states. At each date
the auxiliary draws only integrate the forecast moments conditional on those
incoming states, with exact p/q weights and positive normalized-weight QR.
The density remains a single full-8D Gaussian. This is a new finite-N
algorithm-defined approximation, not the exact nonlinear DSGE likelihood.

V4 uses one prospectively fixed interleaved joint-random coordinate layout
per quarter: for each structural coordinate j, [primary_j, observation_j,
auxiliary_0j,...,auxiliary_7j]. A single counter-based Philox generator
fills the entire row-major N-by-17,945 bank in one call, avoiding the
documented V2/V3 high-dimensional Sobol aliases while retaining prefix.
The scalar interface explicitly uses this class's forecast_path. Importance
tilt remains only at the pilot-identified 2008Q4 date.
"""
from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).absolute().parents[1]/"jw_win_v1"/"code"))
import runtime

import numpy as np
from scipy.linalg import cho_solve, qr, solve_triangular
from scipy.special import ndtri

from normalized_qr_controls import NormalizedQRTarget, model_parts, normal_logscore
from grouped_transition import affine_tables, transition
from fixed_kalman_gain_gaussian_sqrt_v2 import root_condition


K_AUX = 8
PILOT_MU = np.array([-.41, 2.09, 1.50, -.48, -1.70, -.38, -.04, -.42])
ALPHA_ORDINARY = 0.
ALPHA_2008Q4 = .75
RARE_PERIOD = 179
STATE_CHUNK = 256


class AuxiliarySolverError(RuntimeError):
    def __init__(self, t, primary_code1, primary_code2, auxiliary_code1,
                 auxiliary_code2, primary_inputs, auxiliary_inputs):
        self.period = int(t)
        self.ledger = {"primary_code1": int(primary_code1),
                       "primary_code2": int(primary_code2),
                       "auxiliary_code1": int(auxiliary_code1),
                       "auxiliary_code2": int(auxiliary_code2)}
        self.primary_inputs = primary_inputs
        self.auxiliary_inputs = auxiliary_inputs
        super().__init__(f"unresolved OBC selection t={t} {self.ledger}")


class AuxiliaryNumericalError(RuntimeError):
    pass


def orthogonal_proposal_basis(mu=PILOT_MU):
    norm = float(np.linalg.norm(mu))
    if norm <= 0:
        raise ValueError("Proposal shift must be nonzero")
    e = mu/norm
    raw = np.column_stack((e, np.eye(len(mu))[:, 1:]))
    basis, _ = np.linalg.qr(raw)
    if basis[:, 0]@e < 0:
        basis[:, 0] *= -1
    if np.max(np.abs(basis.T@basis-np.eye(len(mu)))) > 1e-13:
        raise RuntimeError("Proposal basis is not orthogonal")
    return basis, norm


PROPOSAL_BASIS, MU_NORM = orthogonal_proposal_basis()


def proposal_from_uniform(u, alpha, sig):
    """Map K*8 independent uniforms to Gaussian-mixture shocks and p/q."""
    u = np.asarray(u, dtype=float).reshape(-1, 8)
    tiny = np.finfo(float).eps
    if alpha == 0:
        z = ndtri(np.clip(u, tiny, 1-tiny))
        return z*sig[None, :], np.ones(len(z)), 0
    if not 0 < alpha < 1:
        raise ValueError("Proposal mixture probability must be interior")
    shifted = u[:, 0] >= 1-alpha
    local = np.where(shifted, (u[:, 0]-(1-alpha))/alpha,
                     u[:, 0]/(1-alpha))
    local = np.clip(local, tiny, 1-tiny)
    v = np.empty_like(u)
    v[:, 0] = ndtri(local)+shifted*MU_NORM
    v[:, 1:] = ndtri(np.clip(u[:, 1:], tiny, 1-tiny))
    z = v@PROPOSAL_BASIS.T
    ratio = np.exp(z@PILOT_MU-.5*MU_NORM**2)
    weights = 1/((1-alpha)+alpha*ratio)
    return z*sig[None, :], weights, int(shifted.sum())


def normalized_weighted_forecast_root(sumw, sumwz, blocks, rchol):
    """QR factor for sum(w/sumw)(Z-m)(Z-m)' + R.

    blocks is a list of (Z,w) pairs so no M*8 array must survive the date.
    """
    mean = sumwz/sumw
    centered = [((Z-mean)*np.sqrt(w/sumw)[:, None]) for Z,w in blocks]
    _, upper = qr(np.vstack((*centered, rchol.T)),
                  mode="economic", check_finite=True)
    signs = np.where(np.diag(upper) < 0, -1., 1.)
    root = upper.T*signs[None, :]
    root_condition(root)
    return mean, root


class AuxiliaryJointQMCGaussianV4(NormalizedQRTarget):
    version = "stationary_F_joint17945_Philox_aux8_fixedK_SNIS_full8D_Gaussian_v4"
    score_mode = "single_full8D_Gaussian_fixedK_auxiliary_SNIS_square_root"

    def __init__(self, N=128, seed=314159, l_max=4, k_max=32):
        N = int(N)
        if N < 2 or N & (N-1):
            raise ValueError("N must be a power of two")
        # Only parse the locked model with a tiny historical bank; replace it
        # completely with one new joint row-major Philox design below.
        super().__init__(N=2, seed=1, l_max=l_max, k_max=k_max)
        self.N = N
        self.qmc_seed = int(seed)
        self.seed = int(seed)
        self.n_aux = K_AUX
        self.joint_dimension = self.nx+len(self.Y)*(
            len(self.shocks)+len(self.obs)+K_AUX*len(self.shocks))
        if self.joint_dimension != 17945:
            raise RuntimeError(f"Unexpected single joint dimension {self.joint_dimension}")
        uniforms = np.random.Generator(
            np.random.Philox(int(seed))).random(
                (N,self.joint_dimension),dtype=np.float64)
        np.clip(uniforms, np.finfo(float).eps,
                1-np.finfo(float).eps, out=uniforms)
        trail = uniforms[:, self.nx:].reshape(
            N, len(self.Y), len(self.shocks), 2+K_AUX)
        self.x_z = ndtri(uniforms[:, :self.nx].copy())
        self.eps_z = ndtri(trail[:, :, :, 0].copy()).transpose(1, 0, 2)
        self.obs_z = ndtri(trail[:, :, :, 1].copy()).transpose(1, 0, 2)
        self.aux_u = trail[:, :, :, 2:].transpose(1, 0, 3, 2)
        self._joint_uniform_bank = uniforms
        self.mus = self.obs_z@np.linalg.cholesky(self.R).T

    def _alpha(self, t):
        return ALPHA_2008Q4 if t == RARE_PERIOD else ALPHA_ORDINARY

    def evaluate_full(self, p, upto=None, return_path=False):
        if return_path:
            raise ValueError("Use forecast_path for explicit score and solver ledger")
        p=np.asarray(p,dtype=float)
        theta=self.estimated_from_full(p)
        if not np.array_equal(self.full_from_estimated(theta),p):
            raise ValueError("Fixed model primitives changed")
        scores,_=self.forecast_path(theta,upto=upto)
        return float(scores.sum())

    def forecast_path(self, theta, upto=None, nonlinear=True,
                      return_diagnostics=False):
        system,F,E,sig,P0,H,J,bq,by = model_parts(self, theta, "transition_F")
        affine_A,affine_b = affine_tables(system)
        X0=self.x_z@self._root_for_mvn(P0).T
        Xn=X0.copy();Xl=X0.copy()
        mk=np.zeros(len(F));Pk=P0.copy()
        nt=len(self.Y) if upto is None else (
            self.ends[upto] if isinstance(upto,str) else int(upto))
        if nt<1 or nt>len(self.Y):
            raise ValueError(f"Invalid endpoint length {nt}")
        scores=np.empty(nt);exact=np.empty(nt)
        flags=np.zeros((nt,4),dtype=np.int64)
        min_eig=np.empty(nt)
        cond=np.empty(nt)
        weight_ess=np.empty(nt)
        shifted_count=np.empty(nt,dtype=np.int64)
        Bx=E*sig[None,:];By=J*sig[None,:]
        Rchol=np.linalg.cholesky(self.R)
        for t,y in enumerate(self.Y[:nt]):
            try:
                aux_eps,aux_w,shifted_count[t]=proposal_from_uniform(
                    self.aux_u[t],self._alpha(t),sig)
                nblocks=[];lblocks=[]
                sn=np.zeros(len(self.obs));sl=sn.copy()
                sumw=0.;sumw2=0.
                aux_code1=aux_code2=0
                bad_aux=[]
                for begin in range(0,self.N,STATE_CHUNK):
                    end=min(begin+STATE_CHUNK,self.N)
                    lo,hi=begin*K_AUX,end*K_AUX
                    xn=np.repeat(Xn[begin:end],K_AUX,axis=0)
                    xl=np.repeat(Xl[begin:end],K_AUX,axis=0)
                    eps=aux_eps[lo:hi]
                    if nonlinear:
                        _,Zn,ac=transition(xn,eps,system,affine_A,affine_b)
                    else:
                        Zn=xn@H.T+eps@J.T+by
                        ac=np.zeros(len(xn),dtype=np.int64)
                    if not np.all(np.isin(ac,(0,1,2))):
                        raise AuxiliaryNumericalError(
                            f"Unknown auxiliary solver flag t={t}")
                    Zl=xl@H.T+eps@J.T+by
                    w=aux_w[lo:hi]
                    nblocks.append((Zn,w));lblocks.append((Zl,w))
                    sn+=w@Zn;sl+=w@Zl
                    sumw+=float(w.sum());sumw2+=float(w@w)
                    aux_code1+=int(np.count_nonzero(ac==1))
                    aux_code2+=int(np.count_nonzero(ac==2))
                    if np.any(ac):
                        bad_aux.append(np.column_stack((xn,eps))[ac!=0])
                eps_primary=self.eps_z[t]*sig
                if nonlinear:
                    Xnf,Zp,pc=transition(Xn,eps_primary,system,
                                        affine_A,affine_b)
                else:
                    Xnf=Xn@F.T+eps_primary@E.T+bq
                    Zp=Xn@H.T+eps_primary@J.T+by
                    pc=np.zeros(self.N,dtype=np.int64)
                if not np.all(np.isin(pc,(0,1,2))):
                    raise AuxiliaryNumericalError(
                        f"Unknown primary solver flag t={t}")
                Xlf=Xl@F.T+eps_primary@E.T+bq
                Zlp=Xl@H.T+eps_primary@J.T+by
                flags[t]=[np.count_nonzero(pc==1),np.count_nonzero(pc==2),
                          aux_code1,aux_code2]
                if np.any(flags[t]):
                    raise AuxiliarySolverError(
                        t,*flags[t],np.column_stack((Xn,eps_primary))[pc!=0],
                        np.vstack(bad_aux) if bad_aux else np.empty((0,self.nx+len(sig))))
                mn,Ln=normalized_weighted_forecast_root(sumw,sn,nblocks,Rchol)
                ml,Ll=normalized_weighted_forecast_root(sumw,sl,lblocks,Rchol)
                weight_ess[t]=sumw**2/sumw2
                m_exact=H@mk+by
                S_exact=H@Pk@H.T+By@By.T+self.R
                S_exact=.5*(S_exact+S_exact.T)
                Lk=np.linalg.cholesky(S_exact)
                cross=F@Pk@H.T+Bx@By.T
                Kexact=cho_solve((Lk,True),cross.T).T
                A=solve_triangular(Ll.T,Lk.T,lower=False,
                                   check_finite=True).T
                B=A@Ln
                c,min_eig[t],_=root_condition(B)
                cond[t]=c*c
                _,upper=qr(B.T,mode="economic",check_finite=True)
                mc=m_exact+(mn-ml)
                scores[t]=normal_logscore(upper,y-mc)
                exact[t]=normal_logscore(Lk.T,y-m_exact)
                innovation=y-m_exact
                mnext=F@mk+bq+Kexact@innovation
                FH=F-Kexact@H;EJ=Bx-Kexact@By
                Pnext=FH@Pk@FH.T+EJ@EJ.T+Kexact@self.R@Kexact.T
                Pnext=.5*(Pnext+Pnext.T)
                Xn=Xnf+(y[None,:]-Zp-self.mus[t])@Kexact.T
                Xl=Xlf+(y[None,:]-Zlp-self.mus[t])@Kexact.T
                mk,Pk=mnext,Pnext
                if not (np.isfinite(scores[t]) and np.all(np.isfinite(Xn))
                        and np.all(np.isfinite(Xl))):
                    raise FloatingPointError("Nonfinite score or state")
            except AuxiliarySolverError:
                raise
            except Exception as exc:
                raise AuxiliaryNumericalError(
                    f"period_zero_based={t} date={1964+t//4}Q{t%4+1} "
                    f"N={self.N} seed={self.qmc_seed} "
                    f"cause={type(exc).__name__}: {exc}") from exc
        if not return_diagnostics:
            return scores,flags.sum(axis=1)
        return {"score_path":scores,"exact_linear_kf_score_path":exact,
                "flag_code_1_primary":flags[:,0],
                "flag_code_2_primary":flags[:,1],
                "flag_code_1_auxiliary":flags[:,2],
                "flag_code_2_auxiliary":flags[:,3],
                "min_corrected_covariance_eigenvalue":min_eig,
                "corrected_covariance_condition_number":cond,
                "auxiliary_weight_ess":weight_ess,
                "auxiliary_shifted_count":shifted_count}
