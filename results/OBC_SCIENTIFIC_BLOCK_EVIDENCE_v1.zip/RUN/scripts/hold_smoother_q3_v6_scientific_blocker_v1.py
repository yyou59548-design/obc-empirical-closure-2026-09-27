"""Record an intentional, resumable hold after an independently audited blocker.

The worker, supervisor, and waiting finalizer must already be stopped after
their command lines have been verified. This script never treats the partial
validation chain as an endpoint result.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "evidence" / "smoother_q3_axis_jump_v6_long_VALIDATION_ONLY"
REGISTRY = ROOT / "jobs_active_20260927.json"
PROTOCOL = OUT / "frozen_long_protocol.json"
PROTOCOL_SHA = "8f0a67848c31630317ab266dd6fe62fc0159a160c6b46c136b0c51e6349e1c81"
HOLD = OUT / "INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER.json"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def main() -> None:
    if HOLD.exists():
        raise FileExistsError("Intentional hold already exists")
    if digest(PROTOCOL) != PROTOCOL_SHA:
        raise RuntimeError("Frozen protocol changed")
    checkpoint = OUT / "chain_00" / "checkpoint_latest.npz"
    with np.load(checkpoint, allow_pickle=False) as stored:
        completed = int(stored["completed_iterations"])
        invalid = int(stored["invalid_solver_evaluations"])
        config_sha = str(stored["frozen_config_sha256"].item())
        last_record = json.loads(str(stored["last_record_json"].item()))
        if last_record["completed_iterations"] != completed or invalid != 0:
            raise RuntimeError("Last complete sweep or solver validity mismatch")
    chain_status_path = OUT / "chain_00" / "status.json"
    chain_status = json.loads(chain_status_path.read_text(encoding="utf-8"))
    if chain_status["frozen_config_sha256"] != config_sha:
        raise RuntimeError("Checkpoint configuration mismatch")
    supervisor_path = OUT / "supervisor_status.json"
    supervisor = json.loads(supervisor_path.read_text(encoding="utf-8"))
    if supervisor["status"] != "RUNNING" or supervisor["active_chain"] != 0:
        raise RuntimeError("Unexpected supervisor status")
    finalizer_path = OUT / "finalizer_status.json"
    finalizer = json.loads(finalizer_path.read_text(encoding="utf-8"))
    if finalizer["status"] != "WAITING":
        raise RuntimeError("Unexpected finalizer status")
    registry = json.loads(REGISTRY.read_text(encoding="utf-8"))
    rows = [row for row in registry["jobs"] if row["name"] == "smoother_q3_axis_jump_v6_long"]
    if len(rows) != 1 or rows[0]["state"] != "RUNNING_CHAIN_0_WITH_WAITING_FINALIZER":
        raise RuntimeError("Unexpected job registry state")
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    hold = {
        "scope": "VALIDATION_ONLY_V6_LONG_INTENTIONAL_HOLD_AFTER_SCIENTIFIC_BLOCKER",
        "utc": now,
        "reason": "Independent original-equation theta-box audit confirmed positive-prior-predictive-mass failure of the locked eventually-slack selected target; this fixed-theta smoother is not an endpoint result.",
        "frozen_protocol_sha256": PROTOCOL_SHA,
        "chain_id": 0,
        "last_complete_atomic_sweep": completed,
        "invalid_solver_evaluations_at_checkpoint": invalid,
        "checkpoint_sha256": digest(checkpoint),
        "checkpoint_bytes": checkpoint.stat().st_size,
        "frozen_config_sha256": config_sha,
        "remaining_chains_not_started": [1, 2, 3],
        "resume_requires": "Explicit review of scientific target; resume only from this atomic checkpoint under the same frozen protocol.",
        "endpoint_result": False,
        "paper_ready": False,
    }
    atomic_json(HOLD, hold)
    chain_status.update(status="INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER", completed_iterations=completed,
                        invalid_solver_evaluations=invalid, updated_utc=now,
                        intentional_hold_path=str(HOLD), endpoint_result=False)
    atomic_json(chain_status_path, chain_status)
    supervisor.update(status="INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER", active_worker_pid=None,
                      active_command=None, updated_utc=now,
                      last_atomic_checkpoint_iterations=completed,
                      intentional_hold_path=str(HOLD), endpoint_result=False)
    atomic_json(supervisor_path, supervisor)
    finalizer.update(status="INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER", updated_utc=now,
                     intentional_hold_path=str(HOLD), endpoint_result=False)
    atomic_json(finalizer_path, finalizer)
    row = rows[0]
    row.update(state="INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER_AT_ATOMIC_CHECKPOINT",
               active_worker_pid_from_status=None, supervisor_pid_from_status=None,
               finalizer_pid_from_status=None, intentional_hold_path=str(HOLD),
               endpoint_result=False)
    atomic_json(REGISTRY, registry)
    log = OUT / "scientific_blocker_hold.log"
    with log.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(hold, ensure_ascii=False, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(hold, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
