"""Directed theta-box norm bound for bounded infinite OBC wedges.

Validation only. This extends the frozen V4 finite-support dual's Fubini
argument to bounded nonnegative wedge sequences on the analytic theta box.
"""
from __future__ import annotations

import gzip
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "tools" / "pyflint"), str(ROOT / "scripts"), str(ROOT / "methods")]

from flint import arb, arb_mat, ctx, fmpq
from threadpoolctl import threadpool_limits

from auxiliary_v4_eaware_dual_adjoint_arb_v4 import aq, mat, one_norm_upper, max_abs_upper
from auxiliary_v4_eaware_green_arb_v4 import row_sum_norm_upper, atomic_json
from auxiliary_v4_actual_arb_krawczyk_pilot_v2 import sha

MODE = "analytic_theta39_box_exp120"
GREEN = ROOT / "evidence" / f"auxiliary_v4_eaware_green_arb_{MODE}_radius1over{10**24}_v4"
CANDIDATE = ROOT / "evidence" / "auxiliary_v4_infinite_geometric_dual_candidate_v1" / "candidate.json"
OUT = ROOT / "evidence" / "auxiliary_v4_theta39_bounded_wedge_bound_v4.json"


def row(matrix: arb_mat, index: int) -> arb_mat:
    result = arb_mat(1, matrix.ncols())
    for column in range(matrix.ncols()):
        result[0, column] = matrix[index, column]
    return result


def main() -> None:
    threadpool_limits(1)
    ctx.prec, ctx.threads = 256, 1
    report_path = GREEN / "report.json"
    green_report = json.loads(report_path.read_text(encoding="utf-8"))
    archive = GREEN / "green_interval_matrices.json.gz"
    if green_report["green_interval_archive_sha256"] != sha(archive):
        raise RuntimeError("V4 Green archive hash mismatch")
    if not green_report["power_contraction_verified"]:
        raise RuntimeError("V4 Green contraction missing")
    with gzip.open(archive, "rt", encoding="utf-8") as stream:
        matrices = json.load(stream)
    if matrices["semantics"] != "analytic_exact_decimal_YAML_theta39_box_exp120":
        raise RuntimeError("theta-box semantic mismatch")
    candidate = json.loads(CANDIDATE.read_text(encoding="utf-8"))
    lam, F, G, L, B, a = (mat(matrices[key]) for key in ("lambda", "F", "G", "L", "B", "a"))
    norm_F_256 = row_sum_norm_upper(F**256)
    norm_B_64 = row_sum_norm_upper(B**64)
    if not norm_F_256 < 1 or not norm_B_64 < 1:
        raise RuntimeError("power contraction missing")
    sum_F = sum((row_sum_norm_upper(F**k) for k in range(256)), arb(0)) / (1 - norm_F_256)
    sum_B = sum((row_sum_norm_upper(B**k) for k in range(64)), arb(0)) / (1 - norm_B_64)
    EG, EL = arb_mat(33, 31), arb_mat(33, 1)
    for i in range(25):
        for j in range(31):
            EG[i, j] = G[i, j]
        EL[i, 0] = L[i, 0]
    row_bound = (
        1 + abs(L[4, 0]).upper() + one_norm_upper(row(G, 4)) * max_abs_upper(a) * sum_B
        + one_norm_upper(row(lam, 4)) * sum_F
        * (row_sum_norm_upper(EG) * max_abs_upper(a) * sum_B + max_abs_upper(EL))
    )
    y_prefix = [aq(value) for value in candidate["first_192_y_binary64_repr"]]
    alpha = aq(candidate["alpha_binary64_repr"])
    if not all(value >= 0 for value in y_prefix) or not alpha >= 0:
        raise RuntimeError("dual weights must be nonnegative for the absolute-mass bound")
    rho = arb(fmpq(199, 200))
    y_mass = sum(y_prefix, arb(0)) + alpha / (1 - rho)
    result = {
        "scope": "VALIDATION_ONLY_V4_THETA39_BOUNDED_INFINITE_WEDGE_FUBINI_NORM",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": {
            "runner": sha(Path(__file__)),
            "green_report": sha(report_path),
            "green_archive": sha(archive),
            "candidate": sha(CANDIDATE),
        },
        "F_power256_inf_norm_upper": float(norm_F_256.upper()),
        "B_power64_inf_norm_upper": float(norm_B_64.upper()),
        "sum_F_power_norm_upper": float(sum_F.upper()),
        "sum_B_power_norm_upper": float(sum_B.upper()),
        "M_uniform_absolute_row_sum_upper": float(row_bound.upper()),
        "dual_y_l1_mass_upper": float(y_mass.upper()),
        "fubini_double_sum_bound_per_unit_lambda_linf": float((row_bound * y_mass).upper()),
        "bounded_infinite_nonnegative_wedge_class_covered": True,
        "unbounded_wedge_class_covered": False,
        "scientific_impossibility_proven": False,
    }
    atomic_json(OUT, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
