"""Bounded 1023D Arb Krawczyk trial for the frozen OBC raw pencil.

All result flags fail closed. A verified inclusion would concern the
source-analytic/captured-float coefficient hull, not the infinite dual.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "tools" / "pyflint"), str(ROOT / "scripts"),
                 str(ROOT / "methods")]

import numpy as np
from flint import arb, arb_mat, ctx, fmpq
from scipy.linalg import solve, inv
from threadpoolctl import threadpool_limits

from auxiliary_joint_qmc_gaussian_v4 import AuxiliaryJointQMCGaussianV4
from auxiliary_v4_actual_graph_pilot_v1 import raw_pencil
import locked_author_likelihood as author
from independent_multispell_milp_v1 import load_capture
from independent_multispell_uncapped_farkas_v3 import HIGH_DENSITY

GRAPH = ROOT / "evidence" / "auxiliary_v4_actual_graph_pilot_v1.json"
LOG = ROOT / "logs" / "auxiliary_v4_actual_arb_krawczyk_pilot_v2.log"
PREC = 256
RADIUS_DEN = int(os.environ.get("OBC_KRAWCZYK_RADIUS_DEN", str(10**8)))
REFINE = int(os.environ.get("OBC_KRAWCZYK_ARB_REFINEMENTS", "0"))
MODE = os.environ.get("OBC_KRAWCZYK_MODE", "source_hull")
if MODE not in ("source_hull", "analytic_exact", "analytic_theta39_box_exp120", "frozen_binary64"):
    raise ValueError(f"Unknown Krawczyk input mode {MODE}")
SOURCE = (ROOT / "evidence" / f"auxiliary_v4_source_primitive_arb_{MODE}_v2"
          if MODE in ("analytic_exact", "analytic_theta39_box_exp120") else
          ROOT / "evidence" / "auxiliary_v4_source_primitive_arb_hull_implementation_v2")
if RADIUS_DEN < 1:
    raise ValueError("Candidate radius denominator must be positive")
OUT = ROOT / "evidence" / (f"auxiliary_v4_actual_arb_krawczyk_{MODE}_radius1over{RADIUS_DEN}"
                            f"{'_refine'+str(REFINE) if REFINE else ''}_v2.json")
TIME_CAP_SECONDS = 1800


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def atomic_gzip_json(path: Path, obj: dict) -> None:
    temp = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temp.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", compresslevel=6) as f:
            f.write(json.dumps(obj, separators=(",", ":"), allow_nan=False).encode())
        raw.flush()
        os.fsync(raw.fileno())
    os.replace(temp, path)


def log(line: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {line}\n")
        f.flush()
        os.fsync(f.fileno())


def qfloat(x) -> arb:
    n, d = float(x).as_integer_ratio()
    return arb(fmpq(n, d))


def unserial(v) -> arb:
    m, e, r, re = map(int, v)
    return arb((m, e), (r, re))


def serial(v: arb) -> list[int]:
    m, e = v.mid().man_exp()
    r, re = v.rad().man_exp()
    return [int(m), int(e), int(r), int(re)]


def matrix_from_sparse(row):
    n, m = row["shape"]
    out = arb_mat(n, m)
    for i, j, a, b, c, d in row["nonzero_interval_entries"]:
        out[i, j] = unserial((a, b, c, d))
    return out


def numeric_pencil(A, B):
    n, m = A.nrows(), A.ncols()
    return (np.asarray([[float(A[i, j].mid()) for j in range(m)]
                        for i in range(n)]),
            np.asarray([[float(B[i, j].mid()) for j in range(m)]
                        for i in range(n)]))


def np_graph(P, N, omega, R, C):
    Q = omega.shape[1]
    X = np.vstack((np.eye(Q), omega))
    L = P[R] @ X
    lam = solve(L, N[R] @ X, assume_a="gen", check_finite=False)
    PCX = P[C] @ X
    V = solve(L.T, PCX.T, assume_a="gen", check_finite=False).T
    U = P[C, Q:] - V @ P[R, Q:]
    W = V @ N[R, Q:] - N[C, Q:]
    H = PCX @ lam - N[C] @ X
    J = np.kron(U, lam.T) + np.kron(W, np.eye(Q))
    return H, J


def amat_X(omega):
    Q = omega.ncols()
    X = arb_mat(Q+omega.nrows(), Q)
    for i in range(Q): X[i, i] = 1
    for i in range(omega.nrows()):
        for j in range(Q): X[Q+i, j] = omega[i, j]
    return X


def select_rows(M, rows):
    out = arb_mat(len(rows), M.ncols())
    for i, r in enumerate(rows):
        for j in range(M.ncols()): out[i, j] = M[r, j]
    return out


def select_cols(M, first):
    out = arb_mat(M.nrows(), M.ncols()-first)
    for i in range(M.nrows()):
        for j in range(out.ncols()): out[i, j] = M[i, first+j]
    return out


def interval_HJ(P, N, omega, R, C, need_J):
    Q = omega.ncols()
    X = amat_X(omega)
    PR, NR = select_rows(P, R), select_rows(N, R)
    PC, NC = select_rows(P, C), select_rows(N, C)
    L = PR*X
    Linv = L.inv()  # Arb certified enclosure or raises on singularity.
    lam = Linv*(NR*X)
    PCX = PC*X
    H = PCX*lam-NC*X
    if not need_J:
        return H, None
    V = PCX*Linv
    U = select_cols(PC, Q)-V*select_cols(PR, Q)
    W = V*select_cols(NR, Q)-select_cols(NC, Q)
    Pdim = omega.nrows()
    J = arb_mat(Pdim*Q, Pdim*Q)
    for i in range(Pdim):
        for a in range(Pdim):
            u, w = U[i, a], W[i, a]
            for k in range(Q):
                for b in range(Q):
                    J[i*Q+k, a*Q+b] = u*lam[b, k] + (w if k == b else 0)
    return H, J


def upper_abs(v):
    return abs(v).upper()


def main() -> None:
    threadpool_limits(1)
    ctx.prec = PREC
    ctx.threads = 1
    start = time.monotonic()
    log("START bounded actual OBC Arb Krawczyk pilot")
    source_report = json.loads((SOURCE / "report.json").read_text(encoding="utf-8"))
    archive = SOURCE / "primitive_interval_sparse.json.gz"
    if source_report["interval_archive_sha256"] != sha(archive):
        raise RuntimeError("Source interval archive hash mismatch")
    with gzip.open(archive, "rt", encoding="utf-8") as f:
        data = json.load(f)
    d, _ = load_capture(HIGH_DENSITY)
    if MODE in ("source_hull", "analytic_exact", "analytic_theta39_box_exp120"):
        P, N = matrix_from_sparse(data["Praw"]), matrix_from_sparse(data["Nraw"])
        Pd, Nd = numeric_pencil(P, N)
    else:
        author.META = Path("O:/RUN/jw_win_v1/source/OBC_CLOSURE_AUDIT_AND_REPAIR_PACKAGE/"
                           "workspace/obc_repro/OBC_frontier_run/reference/previous/raw/"
                           "rank_spreads_exo_ztrend_SW_BAA_6420_ninit_0_meta.npz")
        target = AuxiliaryJointQMCGaussianV4(N=2, seed=456789, l_max=4, k_max=32)
        system = target._system(target.full_from_estimated(np.asarray(d["theta"], float)))
        Pd, Nd, *_ = raw_pencil(target, system)
        P, N = arb_mat(64, 64), arb_mat(64, 64)
        for i in range(64):
            for j in range(64):
                P[i, j], N[i, j] = qfloat(Pd[i, j]), qfloat(Nd[i, j])
    omega0 = np.asarray(d["recurrence_omega"], float)
    graph = json.loads(GRAPH.read_text(encoding="utf-8"))
    R = np.asarray(graph["selected_row_indices"], int)
    C = np.asarray([i for i in range(64) if i not in set(R)], int)
    H0, J0 = np_graph(Pd, Nd, omega0, R, C)
    step = solve(J0, -H0.ravel(), assume_a="gen", check_finite=False)
    omega1 = omega0 + step.reshape(31, 33)
    H1, J1 = np_graph(Pd, Nd, omega1, R, C)
    report = {
        "scope": "VALIDATION_ONLY_OBC_1023D_ARB_KRAWCZYK_BOUNDED_PILOT",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": {"runner": sha(Path(__file__)), "source_interval_archive": sha(archive),
                          "row_selection": sha(GRAPH), "capture": sha(HIGH_DENSITY)},
        "flint_version": "0.9.0", "arb_precision_bits": PREC,
        "coefficient_mode": MODE,
        "candidate_radius": f"1/{RADIUS_DEN}",
        "numeric_initial_newton_step_max_abs": float(np.max(np.abs(step))),
        "numeric_post_newton_residual_max_abs": float(np.max(np.abs(H1))),
        "stage": "INPUTS_VERIFIED", "krawczyk_inclusion_verified": False,
        "scientific_impossibility_proven": False,
    }
    atomic_json(OUT, report)
    log("INPUTS_VERIFIED; numeric Newton center built")
    Cfloat = inv(J1, check_finite=False)
    if time.monotonic()-start > TIME_CAP_SECONDS/2:
        report["stage"] = "TIME_CAP_BEFORE_INTERVAL"
        atomic_json(OUT, report)
        return
    Cmat = arb_mat(1023, 1023)
    for i in range(1023):
        for j in range(1023): Cmat[i, j] = qfloat(Cfloat[i, j])
    center = arb_mat(31, 33)
    box = arb_mat(31, 33)
    radius = arb(fmpq(1, RADIUS_DEN))
    for i in range(31):
        for j in range(33):
            center[i, j] = qfloat(omega1[i, j])
    if REFINE:
        for k in range(REFINE):
            Href, _ = interval_HJ(P, N, center, R, C, False)
            Href_vec = arb_mat(1023, 1)
            for i in range(31):
                for j in range(33): Href_vec[i*33+j, 0] = Href[i, j]
            correction = Cmat*Href_vec
            for i in range(31):
                for j in range(33):
                    center[i, j] = (center[i, j]-correction[i*33+j, 0]).mid()
            report[f"arb_refinement_{k+1}_residual_upper"] = float(max(upper_abs(Href[i, j])
                                                                          for i in range(31) for j in range(33)))
            report["stage"] = f"ARB_REFINEMENT_{k+1}_COMPLETE"
            atomic_json(OUT, report)
            log(report["stage"])
        center_path = OUT.with_suffix(".center.json.gz")
        atomic_gzip_json(center_path, {"shape": [31, 33],
                                       "entries": [serial(center[i, j]) for i in range(31) for j in range(33)]})
        report["center_archive"] = str(center_path)
        report["center_archive_sha256"] = sha(center_path)
    for i in range(31):
        for j in range(33):
            box[i, j] = center[i, j] + arb(0, radius)
    Hc, _ = interval_HJ(P, N, center, R, C, False)
    report["interval_center_H_max_upper"] = float(max(upper_abs(Hc[i, j])
                                                       for i in range(31) for j in range(33)))
    report["stage"] = "CENTER_INTERVAL_COMPLETE"
    atomic_json(OUT, report)
    log(f"CENTER_INTERVAL_COMPLETE elapsed={time.monotonic()-start:.1f}")
    _, Jbox = interval_HJ(P, N, box, R, C, True)
    numeric_J_contained = all(Jbox[i, j].contains(qfloat(J1[i, j]))
                              for i in range(1023) for j in range(1023))
    report["numeric_center_jacobian_entries_contained"] = numeric_J_contained
    report["stage"] = "BOX_JACOBIAN_COMPLETE"
    atomic_json(OUT, report)
    log(f"BOX_JACOBIAN_COMPLETE elapsed={time.monotonic()-start:.1f}")
    if time.monotonic()-start > TIME_CAP_SECONDS*0.75:
        report["stage"] = "TIME_CAP_BEFORE_PRECONDITIONED_PRODUCT"
        atomic_json(OUT, report)
        return
    Hvec = arb_mat(1023, 1)
    for i in range(31):
        for j in range(33): Hvec[i*33+j, 0] = Hc[i, j]
    CH = Cmat*Hvec
    CJ = Cmat*Jbox
    b = max(upper_abs(CH[i, 0]) for i in range(1023))
    eta = arb(0)
    for i in range(1023):
        row = arb(0)
        for j in range(1023):
            v = (1 if i == j else 0) - CJ[i, j]
            row += upper_abs(v)
        eta = max(eta, row.upper())
    condition = b + eta*radius < radius
    report.update({"preconditioned_residual_upper": float(b),
                   "preconditioned_jacobian_defect_norm_upper": float(eta),
                   "krawczyk_radius_condition": bool(condition),
                   "krawczyk_inclusion_verified": bool(condition),
                   "elapsed_seconds": time.monotonic()-start,
                   "stage": "COMPLETE_INTERVAL_TEST"})
    atomic_json(OUT, report)
    log(f"COMPLETE inclusion={condition} b={float(b):.3e} eta={float(eta):.3e} elapsed={report['elapsed_seconds']:.1f}")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
