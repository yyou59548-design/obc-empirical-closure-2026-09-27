"""Fixed-theta source Green stationary Gaussian support check, validation only.

Independent of the Green dual adjoint code. This checks a 21-dimensional
finite controllability subspace of the certified E-aware Green interval.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("O:/RUN")
sys.path[:0] = [str(ROOT / "tools/pyflint"), str(ROOT / "scripts")]

import numpy as np
from flint import arb, arb_mat, ctx, fmpq

INPUT = ROOT / "evidence/auxiliary_joint_qmc_2009_stress_v4/high_density_flag_e625_seed456789_N8192_flagged_inputs.npz"
EVIDENCE = ROOT / "evidence/auxiliary_v4_source_stationary_support_arb_v1"
COLS = [29, 28, 5, 1, 3, 6, 8, 30, 2, 7, 4, 25, 13, 11, 18, 12, 0, 27, 14, 9, 21]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temp.open("w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def unserial(v: list[int]) -> arb:
    m, e, r, re = map(int, v)
    return arb((m, e), (r, re))


def qfloat(x: float) -> arb:
    n, d = float(x).as_integer_ratio()
    return arb(fmpq(n, d))


def eye(n: int) -> arb_mat:
    A = arb_mat(n, n)
    for i in range(n): A[i, i] = 1
    return A


def transpose(A: arb_mat) -> arb_mat:
    B = arb_mat(A.ncols(), A.nrows())
    for i in range(A.nrows()):
        for j in range(A.ncols()): B[j, i] = A[i, j]
    return B


def inf_norm_upper(A: arb_mat) -> arb:
    return max(sum((abs(A[i, j]).upper() for j in range(A.ncols())), arb(0)).upper()
               for i in range(A.nrows()))


def run_mode(mode: str, qin: np.ndarray) -> dict:
    src = ROOT / "evidence" / f"auxiliary_v4_eaware_green_arb_{mode}_radius1over1000000000000000000000000_v3"
    report = json.loads((src / "report.json").read_text(encoding="utf-8"))
    archive = src / "green_interval_matrices.json.gz"
    if not (report.get("power_contraction_verified") and
            report.get("E_projection_explicit") and
            report["green_interval_archive_sha256"] == sha(archive)):
        raise RuntimeError("Uncertified or changed E-aware Green archive")
    with gzip.open(archive, "rt", encoding="utf-8") as f:
        data = json.load(f)
    lam = data["lambda"]
    if lam["shape"] != [33, 33]:
        raise RuntimeError("Green lambda shape changed")
    L = arb_mat(33, 33)
    for i in range(33):
        for j in range(33): L[i, j] = unserial(lam["entries"][33*i+j])
    F, E = arb_mat(25, 25), arb_mat(25, 8)
    for i in range(25):
        for j in range(25): F[i, j] = L[i, j]
        for j in range(8): E[i, j] = L[i, 25+j]
    powers = [eye(25)]
    for _ in range(3): powers.append(powers[-1] * F)
    allcols = arb_mat(25, 32)
    for k in range(4):
        block = powers[k] * E
        for i in range(25):
            for j in range(8): allcols[i, 8*k+j] = block[i, j]
    C = arb_mat(25, len(COLS))
    for i in range(25):
        for j, col in enumerate(COLS): C[i, j] = allcols[i, col]
    gram = transpose(C) * C
    det = gram.det()
    if det.contains(0) or not det > 0:
        raise RuntimeError("Source controllability Gram determinant unverified")
    Cf = np.asarray([[float(C[i, j].mid()) for j in range(len(COLS))]
                     for i in range(25)], float)
    z, *_ = np.linalg.lstsq(Cf, qin[:25], rcond=None)
    Z = arb_mat(len(COLS), 1)
    for j in range(len(COLS)): Z[j, 0] = qfloat(z[j])
    xstar = C * Z
    radius = max(abs(xstar[i, 0]-qfloat(qin[i])).upper() for i in range(25))
    if not radius < arb(fmpq(4, 10**7)):
        raise RuntimeError("Certified source support point misses input ball")
    f256 = inf_norm_upper(F ** 256)
    if not f256 < 1:
        raise RuntimeError("Source physical F contraction failed")
    return {"semantic_mode": mode,
            "green_report_sha256": sha(src / "report.json"),
            "green_archive_sha256": sha(archive),
            "selected_21d_gram_determinant_lower": str(det.lower()),
            "selected_21d_gram_positive": True,
            "source_support_point_to_qin25_linf_upper": str(radius),
            "source_Fphysical_power256_inf_norm_upper": str(f256),
            "source_stationary_gaussian_support_intersects_frozen_input_ball": True}


def main() -> None:
    ctx.prec, ctx.threads = 256, 1
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    with np.load(INPUT, allow_pickle=False) as z:
        qin = np.asarray(z["auxiliary_inputs"][0], float)
    if hashlib.sha256(np.ascontiguousarray(qin).tobytes()).hexdigest() != "418ef31d9f7bebe39f5787dc6bceabf24d7eb96583e871ccaddd7563ffa1a8d5":
        raise RuntimeError("Incoming input hash mismatch")
    modes = {mode: run_mode(mode, qin) for mode in ("analytic_exact", "frozen_binary64")}
    result = {"scope": "VALIDATION_ONLY_FIXED_THETA_E_AWARE_SOURCE_STATIONARY_SUPPORT",
              "generated_utc": datetime.now(timezone.utc).isoformat(),
              "source_sha256": {"runner": sha(Path(__file__)), "input": sha(INPUT)},
              "selected_controllability_column_indices": COLS,
              "modes": modes,
              "theta_open_neighborhood_proven": False,
              "complete_valid_structural_history_proven": False,
              "scientific_impossibility_proven": False,
              "endpoint_result": False}
    atomic_json(EVIDENCE / "summary.json", result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
