"""Directed Arb historical F.T covariance support over the 39D theta box.

Robustness/replication control only; the requested scientific main covariance
uses F and was checked independently in V4.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "tools/pyflint"), str(ROOT / "scripts"), str(ROOT / "methods")]

import numpy as np
from flint import arb, arb_mat, ctx, fmpq

from auxiliary_v4_theta39_source_stationary_support_arb_v4 import (
    INPUT, atomic_json, inf_norm_upper, mat, qfloat, sha, transpose,
)
from auxiliary_joint_qmc_gaussian_v4 import AuxiliaryJointQMCGaussianV4
from auxiliary_v4_actual_graph_pilot_v1 import raw_pencil
from auxiliary_v4_eaware_graph_arb_v3 import interval_ST
from auxiliary_v4_source_green_arb_v2 import block
from independent_multispell_milp_v1 import load_capture
from independent_multispell_uncapped_farkas_v3 import HIGH_DENSITY
import locked_author_likelihood as author

COLS = [29, 11, 28, 27, 4, 3, 5, 16, 9, 6, 1, 2, 0, 13, 7,
        14, 12, 30, 25, 10, 19, 21, 8, 26, 17]
GREEN = ROOT / "evidence/auxiliary_v4_eaware_green_arb_frozen_binary64_radius1over1000000000000000000000000_v3"
V3_MANIFEST = ROOT / "evidence/auxiliary_v4_eaware_chain_v3_manifest.json"
BOX = ROOT / "evidence/auxiliary_v4_theta39_box_support_v1.json"
SCALES = ROOT / "evidence/auxiliary_v4_source_shock_scale_exact_v1/summary.json"
ROWS = ROOT / "evidence/auxiliary_v4_raw_row_elimination_control_v1.json"
PROTOCOL = ROOT / "evidence/auxiliary_v4_theta39_binary64_historical_FT_protocol_v6.md"
OUT = ROOT / "evidence/auxiliary_v4_theta39_binary64_historical_FT_support_arb_v6.json"
LOG = ROOT / "logs/auxiliary_v4_theta39_binary64_historical_FT_support_arb_v6.log"


def log(s: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {s}\n")
        f.flush()
        os.fsync(f.fileno())


def choose(C: arb_mat) -> arb_mat:
    result = arb_mat(25, 25)
    for i in range(25):
        for j, col in enumerate(COLS):
            result[i, j] = C[i, col]
    return result


def all_control(A: arb_mat, Shock: arb_mat) -> arb_mat:
    result = arb_mat(25, 32)
    power = arb_mat(25, 25)
    for i in range(25):
        power[i, i] = 1
    for k in range(4):
        part = power*Shock
        for i in range(25):
            for j in range(8):
                result[i, 8*k+j] = part[i, j]
        power = power*A
    return result


def blocks(L: arb_mat) -> tuple[arb_mat, arb_mat]:
    F, Shock = arb_mat(25, 25), arb_mat(25, 8)
    for i in range(25):
        for j in range(25):
            F[i, j] = L[i, j]
        for j in range(8):
            Shock[i, j] = L[i, 25+j]
    return F, Shock


def main() -> None:
    ctx.prec, ctx.threads = 256, 1
    result = {"scope": "VALIDATION_ONLY_THETA39_BINARY64_HISTORICAL_F_TRANSPOSE_INITIAL_LAW_V6",
              "generated_utc": datetime.now(timezone.utc).isoformat(),
              "source_sha256": {"runner": sha(Path(__file__)), "protocol": sha(PROTOCOL),
                                "v3_manifest": sha(V3_MANIFEST), "theta_box": sha(BOX),
                                "shock_scales": sha(SCALES), "row_partition": sha(ROWS),
                                "raw_pencil_runner": sha(ROOT/"scripts/auxiliary_v4_actual_graph_pilot_v1.py"),
                                "capture": sha(HIGH_DENSITY),
                                "green_report": sha(GREEN/"report.json"),
                                "green_archive": sha(GREEN/"green_interval_matrices.json.gz"),
                                "incoming_archive": sha(INPUT)},
              "theta_dimension": 39, "theta_radius_exponent": 120,
              "selected_controllability_column_indices": COLS,
              "historical_F_transpose_gaussian_full_support_over_box": False,
              "historical_initial_and_current_shock_input_ball_intersect": False,
              "scientific_impossibility_proven": False, "endpoint_result": False,
              "stage": "START"}
    atomic_json(OUT, result)
    log("START")
    vm = json.loads(V3_MANIFEST.read_text(encoding="utf-8"))
    box = json.loads(BOX.read_text(encoding="utf-8"))
    scales = json.loads(SCALES.read_text(encoding="utf-8"))
    gr = json.loads((GREEN/"report.json").read_text(encoding="utf-8"))
    if not (vm["all_runner_and_upstream_hashes_match"]
            and box["all_strict_archive_prior_bounds"] and box["all_strict_natural_prior_support"]
            and box["same_binary64_implementation_parameter_on_box"]
            and scales["all_strictly_positive"]
            and gr["green_interval_archive_sha256"] == result["source_sha256"]["green_archive"]
            and gr["semantic_mode"] == "frozen_implementation_binary64_primitive"):
        raise RuntimeError("Frozen binary source-to-Green or theta-cell evidence missing")
    with gzip.open(GREEN/"green_interval_matrices.json.gz", "rt", encoding="utf-8") as f:
        gd = json.load(f)
    author.META = Path("O:/RUN/jw_win_v1/source/OBC_CLOSURE_AUDIT_AND_REPAIR_PACKAGE/"
                       "workspace/obc_repro/OBC_frontier_run/reference/previous/raw/"
                       "rank_spreads_exo_ztrend_SW_BAA_6420_ninit_0_meta.npz")
    d, _ = load_capture(HIGH_DENSITY)
    target = AuxiliaryJointQMCGaussianV4(N=2, seed=456789, l_max=4, k_max=32)
    system = target._system(target.full_from_estimated(np.asarray(d["theta"], float)))
    Pd, Nd, *_ = raw_pencil(target, system)
    Praw, Nraw = arb_mat(64, 64), arb_mat(64, 64)
    for i in range(64):
        for j in range(64):
            Praw[i, j], Nraw[i, j] = qfloat(Pd[i, j]), qfloat(Nd[i, j])
    for i in range(8):
        for j in range(64):
            if Praw[55+i, j] != (-1 if j == 25+i else 0) or Nraw[55+i, j] != 0:
                raise RuntimeError("Original binary shock-reset row changed")
    rr = json.loads(ROWS.read_text(encoding="utf-8"))
    top, bottom = rr["top_row_indices"], rr["bottom_row_indices"]
    if top[24:32] != list(range(55, 63)):
        raise RuntimeError("Original binary row permutation changed")
    Smat, Tmat = interval_ST(Praw, Nraw, top, bottom)
    omega = mat(gd["omega"])
    Aplain = block(Smat, range(33), range(33)) + block(Smat, range(33), range(33,64))*omega
    det_plain = Aplain.det()
    if det_plain.contains(0):
        raise RuntimeError("Original binary preprocess qmat inverse not certified")
    lam = mat(gd["lambda"])
    Tqq = block(Tmat, range(33), range(33))
    for i in range(8):
        for j in range(33):
            if Aplain[24+i,j] != (-1 if j == 25+i else 0) or Tqq[24+i,j] != 0:
                raise RuntimeError("Binary shock-row qmat bridge changed")
    bridge_residual = Aplain*lam-Tqq
    if not all(bridge_residual[i,j].contains(0) for i in range(33) for j in range(33)):
        raise RuntimeError("Binary original qmat bridge residual excludes zero")
    result.update({"raw_shock_reset_rows_exact": True,
                   "unprojected_A_determinant_interval": str(det_plain),
                   "unprojected_A_determinant_encloses_zero": False,
                   "original_preprocess_qmat_equals_E_aware_Lambda_by_source_algebra": True,
                   "stage": "BINARY_QMAT_BRIDGE_COMPLETE"})
    atomic_json(OUT, result)
    log("BINARY_QMAT_BRIDGE_COMPLETE")
    F, Shock = blocks(lam)
    point_F, point_Shock = F, Shock
    FT, point_FT = transpose(F), transpose(point_F)
    C = choose(all_control(FT, Shock))
    point_C = choose(all_control(point_FT, point_Shock))
    gram_det = (transpose(C)*C).det()
    if gram_det.contains(0) or not gram_det > 0:
        raise RuntimeError("Historical F.T controllability Gram determinant includes zero")
    f256 = inf_norm_upper(F**256)
    if not f256 < 1:
        raise RuntimeError("Physical F power contraction absent")
    result.update({"selected_25d_gram_determinant_lower": str(gram_det.lower()),
                   "selected_25d_gram_positive": True,
                   "F_power256_inf_norm_upper": str(f256),
                   "FT_power256_one_norm_upper_equal_to_F_inf_norm": str(f256),
                   "historical_Lyapunov_covariance_positive_definite": True,
                   "stage": "FULL_RANK_AND_STABILITY_COMPLETE"})
    atomic_json(OUT, result)
    log("FULL_RANK_AND_STABILITY_COMPLETE")
    with np.load(INPUT, allow_pickle=False) as z:
        qin = np.asarray(z["auxiliary_inputs"][0], float)
    if hashlib.sha256(np.ascontiguousarray(qin).tobytes()).hexdigest() != "418ef31d9f7bebe39f5787dc6bceabf24d7eb96583e871ccaddd7563ffa1a8d5":
        raise RuntimeError("Incoming vector changed")
    Cf = np.asarray([[float(point_C[i, j].mid()) for j in range(25)] for i in range(25)], float)
    z_float = np.linalg.solve(Cf, qin[:25])
    Z = arb_mat(25, 1)
    for j in range(25):
        Z[j, 0] = qfloat(float(z_float[j]))
    X = C*Z
    radius = max(abs(X[i, 0]-qfloat(qin[i])).upper() for i in range(25))
    if not radius < arb(fmpq(4, 10**7)):
        raise RuntimeError("Fixed historical F.T support witness misses incoming ball")
    result.update({"fixed_z_binary64_hex": [float(v).hex() for v in z_float],
                   "fixed_support_point_to_qin25_linf_upper": str(radius),
                   "historical_F_transpose_gaussian_full_support_over_box": True,
                   "historical_initial_and_current_shock_input_ball_intersect": True,
                   "stage": "COMPLETE", "generated_utc": datetime.now(timezone.utc).isoformat()})
    atomic_json(OUT, result)
    log("COMPLETE")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
