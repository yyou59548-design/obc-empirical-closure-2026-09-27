"""Atomically finalize the scoped OBC scientific-blocker outcome.

This script integrates independent interval/source and selector audits. It
never marks a paper endpoint, posterior, or mandatory acceptance gate passed.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TASK = Path(
    "C:/Users/ZZH/Documents/Codex/2026-09-26/zip-start-here-cn-md-codex/"
    "work/obc_fresh_20260926_202630/"
    "OBC_CODEX_FULL_EMPIRICAL_CLOSURE_TASK_20260926"
)
FINAL = TASK / "OUTPUT" / "final_status.json"
E = ROOT / "evidence"
V4 = E / "auxiliary_v4_theta39_eaware_chain_manifest_v4.json"
PRIOR = E / "auxiliary_v4_theta39_box_support_v1.json"
DUAL = E / "auxiliary_v4_eaware_dual_adjoint_arb_analytic_theta39_box_exp120_v4.json"
SUPPORT = E / "auxiliary_v4_theta39_source_stationary_support_arb_v4.json"
WEDGE = E / "auxiliary_v4_theta39_bounded_wedge_bound_v4.json"
AUDIT = E / "auxiliary_v4_theta39_adversarial_v1"
ADDENDUM = AUDIT / "manifest_addendum.json"
HOLD = E / "smoother_q3_axis_jump_v6_long_VALIDATION_ONLY" / "INTENTIONAL_HOLD_SCIENTIFIC_BLOCKER.json"
OUT = E / "scientific_blocker_finalization_v1.json"


def read(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    with temp.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def require(condition: bool, description: str) -> None:
    if not condition:
        raise RuntimeError(description)


def main() -> None:
    v4, prior, dual, support, wedge = (read(path) for path in (V4, PRIOR, DUAL, SUPPORT, WEDGE))
    addendum = read(ADDENDUM)
    hold = read(HOLD)
    require(v4["all_runner_and_upstream_hashes_match"] is True, "V4 provenance")
    require(v4["analytic_theta_box_all_certificates_pass"] is True, "V4 analytic theta box")
    require(v4["binary64_theta_box_covered_by_rounding_cell_and_v3_point_certificates"] is True,
            "V4 implementation semantics")
    require(prior["theta_dimension"] == 39 and prior["radius_exponent"] == 120,
            "theta box dimensions")
    require(prior["all_strict_archive_prior_bounds"] is True and
            prior["all_strict_natural_prior_support"] is True and
            prior["same_binary64_implementation_parameter_on_box"] is True,
            "positive prior theta box")
    require(dual["prefix_all_negative"] is True and dual["all_later_negative"] is True and
            dual["full_input_ball_keeps_negative"] is True and
            dual["q_dot_y_full_input_ball_upper"] < 0 and
            dual["prefix_max_upper"] < 0 and
            dual["all_s_ge_1024_normalized_C_upper"] < 0,
            "all-future dual sign")
    require(support["prior_open_box_positive_measure"] is True and
            support["raw_shock_reset_rows_exact"] is True and
            support["original_preprocess_qmat_equals_E_aware_Lambda_by_source_algebra"] is True and
            support["selected_21d_gram_positive"] is True and
            support["all_eight_source_sigmas_strictly_positive"] is True and
            support["source_stationary_gaussian_support_intersects_33d_input_ball"] is True,
            "corrected-F first-period Gaussian support")
    require(wedge["bounded_infinite_nonnegative_wedge_class_covered"] is True and
            wedge["unbounded_wedge_class_covered"] is False,
            "bounded-path scope")
    require(addendum["selected_target_positive_prior_predictive_mass_obstruction"] is True and
            addendum["all_equilibria_absent_proven"] is False and
            addendum["observed_data_posterior_mass_proven"] is False,
            "independent scoped audit conclusion")
    for name, expected in addendum["files_sha256"].items():
        require(sha(AUDIT / name) == expected, f"independent audit hash: {name}")
    require(hold["last_complete_atomic_sweep"] > 0 and hold["endpoint_result"] is False,
            "resumable validation hold")
    checkpoint = E / "smoother_q3_axis_jump_v6_long_VALIDATION_ONLY" / "chain_00" / "checkpoint_latest.npz"
    require(sha(checkpoint) == hold["checkpoint_sha256"], "held checkpoint changed")

    old = read(FINAL)
    require(old.get("paper_ready") is False and old.get("qualified_endpoint_posteriors") == 0,
            "existing final-status scope")
    now = dt.datetime.now(dt.timezone.utc).isoformat()
    evidence = dict(old.get("blocking_evidence", {}))
    evidence.update({
        "locked_selected_target_scientific_blocker": True,
        "proof_scope": "No valid eventually-all-slack finite-support nonnegative wedge on a positive-prior-predictive-mass first-period event; no assertion about all equilibria or observed-data posterior mass.",
        "theta_dimension": 39,
        "theta_box_radius_rule": "2^-120 * max(1, abs(theta0_i))",
        "theta_box_log10_volume_approx": prior["log10_box_volume_approx"],
        "full_input_ball_linf_radius": dual["input_ball_linf_radius"],
        "dual_q_dot_y_upper_on_ball": dual["q_dot_y_full_input_ball_upper"],
        "dual_first_1024_column_max_upper": dual["prefix_max_upper"],
        "dual_all_later_normalized_column_upper": dual["all_s_ge_1024_normalized_C_upper"],
        "corrected_F_support_witness_linf_upper": support["fixed_source_support_point_to_qin25_linf_upper"],
        "selected_21d_gram_determinant_lower": support["selected_21d_gram_determinant_lower"],
        "bounded_green_M_uniform_absolute_row_sum_upper": wedge["M_uniform_absolute_row_sum_upper"],
        "original_equations_E_aware_theta_box_manifest": str(V4),
        "independent_adversarial_conclusion": str(AUDIT / "FINAL_CONCLUSION.md"),
        "independent_adversarial_manifest": str(ADDENDUM),
        "bounded_path_scope_erratum": str(AUDIT / "BOUNDED_CLASS_ERRATUM.md"),
        "validation_smoother_hold": str(HOLD),
        "no_archived_results_promoted": True,
    })
    status = dict(old)
    status.update({
        "run_state": "SCIENTIFIC_BLOCKER_CONFIRMED_LOCKED_SELECTED_TARGET",
        "paper_ready": False,
        "qualified_endpoint_posteriors": 0,
        "target_certified": False,
        "smoothing_complete": False,
        "attribution_complete": False,
        "learning_decomposition_complete": False,
        "robustness_complete": False,
        "simulation_recovery_complete": False,
        "blocking_stage": "A_target_certification_locked_selected_equilibrium_nonexistence_positive_prior_predictive_mass",
        "blocking_evidence": evidence,
        "scientific_impossibility_proven": True,
        "scientific_impossibility_scope": "locked eventually-all-slack find_lk selected target; positive prior-predictive mass at first 1964Q1 transition",
        "all_possible_equilibria_absent_proven": False,
        "observed_data_posterior_positive_mass_proven": False,
        "all_mandatory_gates_passed": False,
        "updated_utc": now,
        "note": "Scientific blocker confirmed for the locked selected target. Validation-only proof diagnostics do not become posterior, smoothing, attribution, or paper results. Model/selector redesign would require a new scientific target and renewed Phase A certification.",
    })
    atomic_json(FINAL, status)
    manifest = {
        "scope": "SCOPED_LOCKED_TARGET_SCIENTIFIC_BLOCKER_FINALIZATION_V1",
        "generated_utc": now,
        "source_sha256": {"runner": sha(Path(__file__)), **{
            label: sha(path) for label, path in (
                ("v4_chain", V4), ("theta_prior_box", PRIOR), ("v4_dual", DUAL),
                ("v4_corrected_F_support", SUPPORT), ("v4_bounded_wedge", WEDGE),
                ("independent_audit_addendum", ADDENDUM), ("v6_hold", HOLD),
                ("task_START_HERE_CN", TASK / "START_HERE_CN.md"),
                ("task_CODEX_MASTER_TASK", TASK / "CODEX_MASTER_TASK.md"),
                ("task_ACCEPTANCE_GATES", TASK / "ACCEPTANCE_GATES.json"),
            )
        }},
        "final_status_path": str(FINAL),
        "final_status_sha256": sha(FINAL),
        "scientific_impossibility_proven_for_locked_selected_target": True,
        "paper_ready": False,
        "all_possible_equilibria_absent_proven": False,
        "observed_data_posterior_positive_mass_proven": False,
        "qualified_endpoint_posteriors": 0,
        "v6_validation_only_checkpoint_sha256": hold["checkpoint_sha256"],
    }
    atomic_json(OUT, manifest)
    print(json.dumps({"final_status": str(FINAL), "manifest": str(OUT),
                      "final_status_sha256": manifest["final_status_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
