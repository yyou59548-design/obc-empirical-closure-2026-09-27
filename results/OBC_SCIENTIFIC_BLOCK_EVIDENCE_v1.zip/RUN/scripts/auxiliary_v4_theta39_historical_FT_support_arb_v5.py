"""Directed Arb historical F.T covariance support over the 39D theta box.

Robustness/replication control only; the requested scientific main covariance
uses F and was checked independently in V4.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "tools/pyflint"), str(ROOT / "scripts"), str(ROOT / "methods")]

import numpy as np
from flint import arb, arb_mat, ctx, fmpq

from auxiliary_v4_theta39_source_stationary_support_arb_v4 import (
    GREEN, INPUT, POINT, atomic_json, inf_norm_upper, mat,
    qfloat, sha, transpose,
)

COLS = [29, 11, 28, 27, 4, 3, 5, 16, 9, 6, 1, 2, 0, 13, 7,
        14, 12, 30, 25, 10, 19, 21, 8, 26, 17]
V4_MANIFEST = ROOT / "evidence/auxiliary_v4_theta39_eaware_chain_manifest_v4.json"
V4_SUPPORT = ROOT / "evidence/auxiliary_v4_theta39_source_stationary_support_arb_v4.json"
PROTOCOL = ROOT / "evidence/auxiliary_v4_theta39_historical_FT_support_protocol_v5.md"
OUT = ROOT / "evidence/auxiliary_v4_theta39_historical_FT_support_arb_v5.json"
LOG = ROOT / "logs/auxiliary_v4_theta39_historical_FT_support_arb_v5.log"


def log(s: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {s}\n")
        f.flush()
        os.fsync(f.fileno())


def choose(C: arb_mat) -> arb_mat:
    result = arb_mat(25, 25)
    for i in range(25):
        for j, col in enumerate(COLS):
            result[i, j] = C[i, col]
    return result


def all_control(A: arb_mat, Shock: arb_mat) -> arb_mat:
    result = arb_mat(25, 32)
    power = arb_mat(25, 25)
    for i in range(25):
        power[i, i] = 1
    for k in range(4):
        part = power*Shock
        for i in range(25):
            for j in range(8):
                result[i, 8*k+j] = part[i, j]
        power = power*A
    return result


def blocks(L: arb_mat) -> tuple[arb_mat, arb_mat]:
    F, Shock = arb_mat(25, 25), arb_mat(25, 8)
    for i in range(25):
        for j in range(25):
            F[i, j] = L[i, j]
        for j in range(8):
            Shock[i, j] = L[i, 25+j]
    return F, Shock


def main() -> None:
    ctx.prec, ctx.threads = 256, 1
    result = {"scope": "VALIDATION_ONLY_THETA39_HISTORICAL_F_TRANSPOSE_INITIAL_LAW_V5",
              "generated_utc": datetime.now(timezone.utc).isoformat(),
              "source_sha256": {"runner": sha(Path(__file__)), "protocol": sha(PROTOCOL),
                                "v4_manifest": sha(V4_MANIFEST), "v4_support": sha(V4_SUPPORT),
                                "green_report": sha(GREEN/"report.json"),
                                "green_archive": sha(GREEN/"green_interval_matrices.json.gz"),
                                "point_report": sha(POINT/"report.json"),
                                "point_archive": sha(POINT/"green_interval_matrices.json.gz"),
                                "incoming_archive": sha(INPUT),
                                "v4_support_runner": sha(ROOT/"scripts/auxiliary_v4_theta39_source_stationary_support_arb_v4.py")},
              "theta_dimension": 39, "theta_radius_exponent": 120,
              "selected_controllability_column_indices": COLS,
              "historical_F_transpose_gaussian_full_support_over_box": False,
              "historical_initial_and_current_shock_input_ball_intersect": False,
              "scientific_impossibility_proven": False, "endpoint_result": False,
              "stage": "START"}
    atomic_json(OUT, result)
    log("START")
    vm = json.loads(V4_MANIFEST.read_text(encoding="utf-8"))
    vs = json.loads(V4_SUPPORT.read_text(encoding="utf-8"))
    gr = json.loads((GREEN/"report.json").read_text(encoding="utf-8"))
    pr = json.loads((POINT/"report.json").read_text(encoding="utf-8"))
    if not (vm["all_runner_and_upstream_hashes_match"] and vm["analytic_theta_box_all_certificates_pass"]
            and vs["all_eight_source_sigmas_strictly_positive"] and vs["original_preprocess_qmat_equals_E_aware_Lambda_by_source_algebra"]
            and gr["green_interval_archive_sha256"] == result["source_sha256"]["green_archive"]
            and pr["green_interval_archive_sha256"] == result["source_sha256"]["point_archive"]
            and vs["source_sha256"]["runner"] == result["source_sha256"]["v4_support_runner"]):
        raise RuntimeError("Frozen source-to-Green or V4 bridge evidence missing")
    with gzip.open(GREEN/"green_interval_matrices.json.gz", "rt", encoding="utf-8") as f:
        gd = json.load(f)
    with gzip.open(POINT/"green_interval_matrices.json.gz", "rt", encoding="utf-8") as f:
        pd = json.load(f)
    F, Shock = blocks(mat(gd["lambda"]))
    point_F, point_Shock = blocks(mat(pd["lambda"]))
    FT, point_FT = transpose(F), transpose(point_F)
    C = choose(all_control(FT, Shock))
    point_C = choose(all_control(point_FT, point_Shock))
    gram_det = (transpose(C)*C).det()
    if gram_det.contains(0) or not gram_det > 0:
        raise RuntimeError("Historical F.T controllability Gram determinant includes zero")
    f256 = inf_norm_upper(F**256)
    if not f256 < 1:
        raise RuntimeError("Physical F power contraction absent")
    result.update({"selected_25d_gram_determinant_lower": str(gram_det.lower()),
                   "selected_25d_gram_positive": True,
                   "F_power256_inf_norm_upper": str(f256),
                   "FT_power256_one_norm_upper_equal_to_F_inf_norm": str(f256),
                   "historical_Lyapunov_covariance_positive_definite": True,
                   "stage": "FULL_RANK_AND_STABILITY_COMPLETE"})
    atomic_json(OUT, result)
    log("FULL_RANK_AND_STABILITY_COMPLETE")
    with np.load(INPUT, allow_pickle=False) as z:
        qin = np.asarray(z["auxiliary_inputs"][0], float)
    if hashlib.sha256(np.ascontiguousarray(qin).tobytes()).hexdigest() != "418ef31d9f7bebe39f5787dc6bceabf24d7eb96583e871ccaddd7563ffa1a8d5":
        raise RuntimeError("Incoming vector changed")
    Cf = np.asarray([[float(point_C[i, j].mid()) for j in range(25)] for i in range(25)], float)
    z_float = np.linalg.solve(Cf, qin[:25])
    Z = arb_mat(25, 1)
    for j in range(25):
        Z[j, 0] = qfloat(float(z_float[j]))
    X = C*Z
    radius = max(abs(X[i, 0]-qfloat(qin[i])).upper() for i in range(25))
    if not radius < arb(fmpq(4, 10**7)):
        raise RuntimeError("Fixed historical F.T support witness misses incoming ball")
    result.update({"fixed_z_binary64_hex": [float(v).hex() for v in z_float],
                   "fixed_support_point_to_qin25_linf_upper": str(radius),
                   "historical_F_transpose_gaussian_full_support_over_box": True,
                   "historical_initial_and_current_shock_input_ball_intersect": True,
                   "stage": "COMPLETE", "generated_utc": datetime.now(timezone.utc).isoformat()})
    atomic_json(OUT, result)
    log("COMPLETE")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
