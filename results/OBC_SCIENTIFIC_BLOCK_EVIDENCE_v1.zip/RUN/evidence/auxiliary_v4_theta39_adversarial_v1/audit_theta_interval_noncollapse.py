"""Read-only exact-rational comparison of point and 39D-box primitive balls."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

ROOT = Path("O:/RUN/evidence")
HERE = Path(__file__).resolve().parent
POINT = ROOT / "auxiliary_v4_source_primitive_arb_analytic_exact_v2/primitive_interval_sparse.json.gz"
BOX = ROOT / "auxiliary_v4_source_primitive_arb_analytic_theta39_box_exp120_v4/primitive_interval_sparse.json.gz"
BOX_SPEC = ROOT / "auxiliary_v4_theta39_box_support_v1.json"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for buf in iter(lambda: f.read(1 << 20), b""):
            h.update(buf)
    return h.hexdigest()


def dyadic(m: int, e: int) -> Fraction:
    return Fraction(m * (1 << e)) if e >= 0 else Fraction(m, 1 << (-e))


def ball(entry: list[int]) -> tuple[Fraction, Fraction, Fraction]:
    m, e, r, re = entry
    mid, rad = dyadic(m, e), dyadic(r, re)
    assert rad >= 0
    return mid-rad, mid+rad, rad


def sparse(archive: dict, name: str) -> dict[tuple[int,int], list[int]]:
    return {(int(i), int(j)): [int(x) for x in data]
            for i, j, *data in archive[name]["nonzero_interval_entries"]}


def main() -> None:
    with gzip.open(POINT, "rt", encoding="utf-8") as f: point = json.load(f)
    with gzip.open(BOX, "rt", encoding="utf-8") as f: box = json.load(f)
    spec = json.loads(BOX_SPEC.read_text(encoding="utf-8"))
    assert spec["theta_dimension"] == 39 and spec["radius_exponent"] == 120
    assert all(c["same_binary64_for_entire_real_box"] and c["strict_archive_bounds"] and
               c["strict_natural_prior_support"] for c in spec["coordinate_checks"])
    out = {}
    total_widened = 0
    for name in ("A", "B", "C", "D", "Praw", "Nraw"):
        p, b = sparse(point, name), sparse(box, name)
        assert point[name]["shape"] == box[name]["shape"]
        widened = point_nonzero = box_nonzero = 0
        max_widen = Fraction(0)
        for key in p.keys() | b.keys():
            pl, pu, pr = ball(p.get(key, [0,0,0,0]))
            bl, bu, br = ball(b.get(key, [0,0,0,0]))
            if not (bl <= pl and pu <= bu):
                raise RuntimeError(f"39D box does not contain center ball: {name} {key}")
            if key in p: point_nonzero += 1
            if key in b: box_nonzero += 1
            if br > pr:
                widened += 1
                max_widen = max(max_widen, br-pr)
        total_widened += widened
        out[name] = {"point_nonzero_entries": point_nonzero,
                     "box_nonzero_entries": box_nonzero,
                     "entries_with_strictly_wider_radius": widened,
                     "max_radius_increment_float": float(max_widen)}
    if not total_widened:
        raise RuntimeError("Theta box collapsed to point at primitive stage")
    result = {"scope": "READ_ONLY_THETA39_INTERVAL_NONCOLLAPSE_AUDIT",
              "generated_utc": datetime.now(timezone.utc).isoformat(),
              "point_archive_sha256": sha(POINT), "box_archive_sha256": sha(BOX),
              "box_spec_sha256": sha(BOX_SPEC), "matrices": out,
              "total_entries_strictly_widened": total_widened,
              "all_point_interval_entries_contained_by_box": True,
              "theta_box_has_positive_volume": True,
              "scientific_impossibility_proven": False}
    HERE.mkdir(parents=True, exist_ok=True)
    dst = HERE / "noncollapse_summary.json"
    tmp = dst.with_name(dst.name + f".tmp.{os.getpid()}")
    tmp.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    tmp.replace(dst)
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
