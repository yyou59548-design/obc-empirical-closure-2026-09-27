"""Read-only independent provenance and logical checks for V4/V5 addenda."""

import hashlib
import json
from pathlib import Path

ROOT = Path("O:/RUN")
EVIDENCE = ROOT / "evidence"
SCRIPTS = ROOT / "scripts"
OUT = EVIDENCE / "auxiliary_v4_theta39_adversarial_v1" / "addenda_summary.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit_one(report_path: Path, paths: dict[str, Path]) -> dict:
    report = json.loads(report_path.read_text(encoding="utf-8"))
    mismatches = {}
    for label, path in paths.items():
        actual = sha(path)
        expected = report["source_sha256"][label]
        if actual != expected:
            mismatches[label] = {"actual": actual, "expected": expected}
    return {"report_sha256": sha(report_path), "hash_mismatches": mismatches}


def main() -> None:
    wedge_path = EVIDENCE / "auxiliary_v4_theta39_bounded_wedge_bound_v4.json"
    v5_path = EVIDENCE / "auxiliary_v4_theta39_historical_FT_support_arb_v5.json"
    green = EVIDENCE / "auxiliary_v4_eaware_green_arb_analytic_theta39_box_exp120_radius1over1000000000000000000000000_v4"
    point = EVIDENCE / "auxiliary_v4_eaware_green_arb_analytic_exact_radius1over1000000000000000000000000_v3"
    wedge = audit_one(wedge_path, {
        "runner": SCRIPTS / "auxiliary_v4_theta39_bounded_wedge_bound_v4.py",
        "green_report": green / "report.json",
        "green_archive": green / "green_interval_matrices.json.gz",
        "candidate": EVIDENCE / "auxiliary_v4_infinite_geometric_dual_candidate_v1" / "candidate.json",
    })
    v5 = audit_one(v5_path, {
        "runner": SCRIPTS / "auxiliary_v4_theta39_historical_FT_support_arb_v5.py",
        "protocol": EVIDENCE / "auxiliary_v4_theta39_historical_FT_support_protocol_v5.md",
        "v4_manifest": EVIDENCE / "auxiliary_v4_theta39_eaware_chain_manifest_v4.json",
        "v4_support": EVIDENCE / "auxiliary_v4_theta39_source_stationary_support_arb_v4.json",
        "green_report": green / "report.json",
        "green_archive": green / "green_interval_matrices.json.gz",
        "point_report": point / "report.json",
        "point_archive": point / "green_interval_matrices.json.gz",
        "incoming_archive": EVIDENCE / "auxiliary_joint_qmc_2009_stress_v4" / "high_density_flag_e625_seed456789_N8192_flagged_inputs.npz",
        "v4_support_runner": SCRIPTS / "auxiliary_v4_theta39_source_stationary_support_arb_v4.py",
    })
    wedge_report = json.loads(wedge_path.read_text(encoding="utf-8"))
    v5_report = json.loads(v5_path.read_text(encoding="utf-8"))
    assert wedge_report["bounded_infinite_nonnegative_wedge_class_covered"]
    assert not wedge_report["unbounded_wedge_class_covered"]
    assert wedge_report["M_uniform_absolute_row_sum_upper"] < 4e8
    assert wedge_report["dual_y_l1_mass_upper"] < 1.003
    assert v5_report["stage"] == "COMPLETE"
    assert v5_report["selected_25d_gram_positive"]
    assert v5_report["historical_initial_and_current_shock_input_ball_intersect"]
    result = {"wedge": wedge, "historical_FT": v5,
              "all_hashes_match": not wedge["hash_mismatches"] and not v5["hash_mismatches"],
              "status_flags_untouched": not wedge_report["scientific_impossibility_proven"] and
              not v5_report["scientific_impossibility_proven"] and not v5_report["endpoint_result"]}
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
