# Adversarial audit: geometric infinite dual candidate

**Decision:** The state-space indexing and signs agree with the frozen
finite-H source response. The present output remains a **numerical candidate**:
neither the source primitive-to-operator interval enclosure nor the sign of
every future column has been proved. It cannot establish scientific
impossibility, certify the endpoint, or change `paper_ready`.

## Independent finite-H controls

For the fixed auxiliary ordinal-0 incoming 33-vector (SHA-256
`418ef31d9f7bebe39f5787dc6bceabf24d7eb96583e871ccaddd7563ffa1a8d5`),
I rebuilt the all-slack transformed source sparse systems at H128 and H192,
then checked their baseline paths against the original untransformed 55
primitive equations.
An independent state-space impulse construction and a separate finite dual
column recurrence gave:

| Check | H128 max absolute difference | H192 max absolute difference |
| --- | ---: | ---: |
| Impulse response `M` against transformed sparse solve | 3.18e-14 | 3.15e-14 |
| Baseline `q` against sparse solve | 5.62e-13 | 5.62e-13 |
| Dual `c=Mᵀy` against sparse solve | 2.80e-14 | 2.78e-14 |
| Sparse source base-equation residual | 1.15e-14 | 1.64e-14 |
| Sparse source wedge-equation residual | 1.23e-15 | 1.42e-15 |
| Original untransformed 55-equation baseline residual | 3.11e-14 | 2.58e-14 |

The rank-one source identity passes at the stored binary64 level.
`omega @ E` is **not** `omega` globally (maximum difference 6.04), so a
primitive proof may not assume that identity. The actually reached `qfull`
shock rows from `lam`, `G`, and `L` are zero to at most 1.3e-14 in binary64;
on that reachable subspace the potentially different `omega E` terms cancel
to at most 1.2e-14. This reachability restriction needs an exact/interval
proof when moving beyond the frozen numerical operator.

## Recurrence and indexing

Write incoming state `e_t`, deviation `d_t=p_t-omega e_t`, and wedge `λ_t`.
On the reachable shock-free output subspace, the source equations imply

```
d_t       = B d_(t+1) + a λ_t
qfull_t   = lam e_t + G d_(t+1) + L λ_t
e_(t+1)   = F e_t + E G d_(t+1) + E L λ_t,  F=E lam.
```

For a unit wedge in period `s`, `X_0=0` and
`X_(s+1)=E G+F X_s B` give `e_s=X_s a`.
The current-column term is
`y_s[1+h X_s a+L_j]`, including the **direct** `+1` wedge in slack.
Past dual weights evolve as
`pastA <- pastA B+y_s h X_s B` and
`pastB <- pastB B+y_s G_j`. Future weights are
`v_s=Σ_(t>s) y_t h F^(t-s-1)`, multiplying
`F X_s a+E L`. These are the terms and index shifts used by the candidate.

At `T=192`, for `y_(T+k)=alpha rho^k`, the code's
`v_(T-1)=alpha h(I-rho F)^(-1)` and
`v_s=alpha rho^(s+1-T) h(I-rho F)^(-1)` for `s>=T`
have the correct first-tail-period offset. The baseline formula is likewise

```
Σ_(t<T) y_t [h F^t e_0-xbar]
  + alpha [h(I-rho F)^(-1)F^T e_0 - xbar/(1-rho)].
```

It matches the implementation's `q_y_infinite_numeric=-0.02606945165371198`
as a binary64 calculation, subject to interval verification of the primitive
model.

## Output scale correction and proof gaps

The candidate's `leading=-2.0531141792775816` is the asymptotic coefficient
of **`alpha*rho^(s-T)`**, whereas the JSON key
`asymptotic_normalized_column_coefficient_numeric` implies normalization by
`rho^(s-T)` alone. That displayed quantity omits `alpha=7.224524343770655e-05`.
On the JSON normalization, the value is **-0.00014832773368731597**, matching
the reported `s=4095` normalized value. This scale error does not change its
sign; the frozen candidate script and manifest were left untouched.

The 4,096-column scan, negative asymptotic *numerical* leading coefficient,
and spectral radii below `rho=0.995` do not bound every intermediate column.
For all `s>=T`, an outward-rounded inequality must control transient and
nonnormal matrix powers, the finite-prefix contribution, and `X_s-X_infinity`.
`X` after the 4,096th iteration is used as `xlim` without a certified error
bound. A directed interval reconstruction from the source 55 primitive
equations is also missing; treating stored `S,T,omega,lam` binary64 values as
exact dyadics would prove a narrower claim. The candidate has not established
an open positive-probability neighborhood in the actual locked row/theta
distribution. No finite scan supports a universal `c_s<=0` inference.

Machine-readable control:
`finite_response_recurrence_audit.json` (created by
`O:\RUN\scripts\audit_auxiliary_v4_geometric_dual_recurrence_v1.py`).
