# E-aware 39D theta-box interval validation, V4

Status: VALIDATION_ONLY. Freeze this protocol before executing any V4 runner.

## Input and parameter semantics

The 39 coordinates are the estimated parameter names and exact binary64 centers
in `auxiliary_v4_theta39_box_support_v1.json`. Coordinate `i` ranges over the
closed rational interval centered at theta0_i with radius
`2^-120 max(1, abs(theta0_i))`. The support report verifies every coordinate
strictly inside its archived and natural-prior bounds and its binary64 rounding
cell. The box has strictly positive 39D volume; its implementation binary64
parameter vector is constant over the entire box. The analytic model evaluates
original source YAML decimal literals exactly and all 39 varying coordinates
outward with python-flint 0.9.0 Arb at 256 bits. These are distinct semantics.

## Directed proof chain

Copy frozen source primitive V2 and E-aware graph, Green, dual V3 scripts to
separate V4 filenames. Before any run, update only paths/output names and the
dual semantic selector. Never change V3 reports or scripts. The V4 source
archive must retain all original 49x50 symbolic equation coefficients, six lag
identities, raw policy row and 64x64 pencil. The graph test uses the E-projected
future state and 1e-24 box around an interval-refined 31x33 graph center; the
1,023D Krawczyk criterion must be strict. The Green bridge must verify row
elimination structure, source graph residual enclosure, F^256 and B^64
contraction. The fixed nonnegative 192-plus-geometric dual uses independent
directed Arb evaluation of all columns s<1,024, a contraction remainder for
every s>=1,024, and a full 33D incoming-input ball of L-infinity radius 4e-7.

The implementation semantic branch is already point-certified by frozen V3.
For the real theta box it is covered only after checking each box coordinate
lies strictly in its binary64 rounding cell and verifying all V3 runner hashes.

## Source stationary support

From the V4 Green interval Lambda_E, use Fphysical=Lambda_E[:25,:25] and
Eshock=Lambda_E[:25,25:33]. Form 32 columns [Eshock, Fphysical Eshock,
Fphysical^2 Eshock, Fphysical^3 Eshock]. Use the fixed indices
[29,28,5,1,3,6,8,30,2,7,4,25,13,11,18,12,0,27,14,9,21]. Compute one
fixed binary64 least-squares coefficient vector z at the frozen analytic point
and then hold its exact dyadic values fixed for the whole box. Check directed
Arb Gram det(C'C)>0, sup-norm |C(theta)z-qin[:25]|<4e-7, Fphysical^256 norm<1,
and all eight source shock standard deviations strictly positive on the box.
This proves support for the analytic model's stationary Gaussian physical
state and current shock input in this box only after bridging to the original
`preprocess` initial law. In particular, reconstruct the unprojected matrix
`A0=Sqq+Sqp*Omega` from original interval source rows and certify its
invertibility. The raw eight shock rows must give the exact row identity
`(I-E)*Lambda_E=0` by source algebra. Then
`A0*Lambda_E = (Sqq+Sqp*Omega*E)*Lambda_E = Tqq`, so the original
`qmat=A0^-1*Tqq` equals Lambda_E. Numerical closeness alone is insufficient.

## Recovery and fail-closed outputs

Each stage writes its own atomic JSON checkpoint and append-only log. Do not
start a downstream stage unless the upstream hash and relevant strict booleans
pass. Limit the 1,023D graph stage to the existing 900-second internal cap;
abort rather than relax the radius. Do not start duplicate workers. At the end
write an independent SHA manifest covering runner scripts, source archive,
graph report/center, Green report/archive, dual report, support report and
upstream V3/binary64 support. Failure leaves all final flags false. Neither a
successful V4 chain nor a failed V4 stage alone proves overall impossibility;
adversarial review and admissible-path/initial-law interpretation remain.
